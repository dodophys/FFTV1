package Usage;
import GUI.*;
public class Main {
	public static void main(String args[]){
		 Display cu=new Display("dodo's");
	}
}
