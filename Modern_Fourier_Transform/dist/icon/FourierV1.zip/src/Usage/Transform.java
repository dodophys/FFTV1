package Usage;
import java.util.Arrays;
import java.awt.image.BufferedImage;
import java.math.*;
import java.awt.image.Raster;
import java.awt.Image;
public class Transform {
	public static BufferedImage Fourier(BufferedImage image){
		int [][] pixels= getPixelsArray(image);
		int w=image.getWidth();
		int h=image.getHeight();
		int[][] Fourier=FFT(pixels,w,h);
		return ArrayToImage(Fourier,image) ;
	}
	private static int set2Power(int i){
		int num=0;
		while(i>0){
			i=(i>>1);
			++num;
		}
		
		if(num>0) i=(1<<(num-1));
	return i;
	}
	
	private static int[][] FFT(int[][]pixels,int w,int h){
		int wprime=set2Power(w);
		int hprime=set2Power(h);
		System.out.println(hprime+" "+w);
		Complex comp[][]=new Complex[wprime][hprime];
		for(int i=0;i<wprime;++i){
			comp[i]=new Complex[hprime];
		}
		for(int i=0;i<wprime;++i){
			for(int j=0;j<hprime;++j){
			System.out.println(pixels[i][j]);
				Complex cp=new Complex();
				cp.setReal(pixels[i][j]);
				comp[i][j]=cp;
			}
		}
		FFTTwoD ft=new FFTTwoD(wprime,hprime);
		comp = ft.fft (comp);
		int[][] Fourier=new int[w][h];
		for(int i=0;i<wprime;++i){
			for(int j=0;j<hprime;++j){
				Fourier[i][j]=Math.round(comp[i][j].amp()*10000);
			}
		}
		return Fourier;
	}
	
	
	private static int[][] DFT(int [][] pixels,int w,int h){
		
		int[][] Fourier=new int[w][h];
		
		for (int u=0;u<w;++u){
			for(int v=0;v<h;++v){
				Complex temp3=new Complex(0,0);
				for(int x=0;x<w;++x){
					Complex temp2=new Complex(0,0);
					for(int y=0;y<h;++y){
						Complex temp1 = Complex.expi(-2.0*Math.PI*y*v/h);
						temp1.multiply(pixels[x][y]);
						temp2.add(temp1);
					}
					Complex temp1 = Complex.expi(-2.0*Math.PI*x*u/h);
					temp2.multiply(temp1);
					temp3.add(temp2);
				}
				temp3.multiply(1/(h*w));
				Fourier[u][v]=(int)Math.round(temp3.amp());
			}
			
		}
		return Fourier;
	}
	
	
	private static int[][] getPixelsArray(BufferedImage image){
		int w=image.getWidth();
		int h=image.getHeight();
		//System.out.println(w+" "+h);
		int [][] pixels = new int[w][h];
		 Raster raster = image.getData();
		 for (int j = 0; j < w; j++) {
		     for (int k = 0; k < h; k++) {
		         pixels[j][k] = raster.getSample(j, k, 0);
		     }
		 }
		 return pixels;
	}
	private static BufferedImage  ArrayToImage(int [][] pixels,BufferedImage image){
		int w=image.getWidth();
		int h=image.getHeight();
		BufferedImage dest = new BufferedImage(image.getWidth(),image.getHeight(),BufferedImage.TYPE_BYTE_GRAY);
		int array[]=new int[w*h];
		for(int i=0;i<w;++i){
			for(int j=0;j<h;++j){
				array[i*w+j]=pixels[i][j];
			}
		}
		Arrays.sort(array);
		float m= (float) (array[w*h/2]/125.0);
		System.out.println(m);
		for(int i=0;i<w;++i){
			for(int j=0;j<h;++j){
				pixels[i][j]=Math.round(pixels[i][j]/m);
			}
		}
		for(int i=0;i<w;++i){
			for(int j=0;j<h;++j){
				dest.setRGB(i, j, pixels[i][j]);
			}
		}
		return dest;
	}
}
